/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automatedtellermachine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author mynew
 */
public class Login extends AutomatedTellerMachine {
        // Method to log in and perform operations
    public void loginAndOperate() {
        Scanner scanner = new Scanner(System.in);
        System.out.print(" Enter your account number        : ");
        String accountNumber = scanner.nextLine();
        System.out.print(" Enter your PIN                   : ");
        String pin = scanner.nextLine();
        boolean loop = false;
    while(!loop){
        // Check if the account exists and the PIN is correct
        File file = new File(accountNumber + ".txt");
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                boolean authenticated = false;
                String fullName = "";
                double balance = 0;
                String date = "";

                // Read account details from the file
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("PIN:") && line.substring(5).trim().equals(pin)) {
                        authenticated = true;
                    }
                    if (line.startsWith("Full name:")) {
                        fullName = line.substring(10);
                    }
                    if (line.startsWith("Balance:")) {
                        balance = Double.parseDouble(line.substring(9));
                    }
                    if (line.startsWith("Date:")){
                        date = line.substring(5);
                    }
                }

                if (authenticated) {
                    System.out.println("Welcome, " + fullName + "!");
                    

                    // Perform operations
                    System.out.println("What would you like to do?");
                    System.out.println("1. Deposit");
                    System.out.println("2. Withdraw");
                    System.out.println("3. Check Balance");
                    System.out.println("4. Exit");
                    System.out.print  (" : ");
                    int choice = scanner.nextInt();
                    switch (choice) {
                        
                        
                        
                        
                        //deposit
                        case 1:
                            System.out.print("Enter amount to deposit     : ");
                            double depositAmount = scanner.nextDouble();
                            balance += depositAmount;
                            updateBalance(accountNumber, balance);
                            System.out.println("Balance updated successfully.");
                            System.out.println("Would you like another transaction?");
                            System.out.println("1. Yes");
                            System.out.println("2. No");
                            System.out.print(": ");
                            int input5 = scanner.nextInt();
                            
                            if(input5 == 1){
                                
                                loop = false;
                            }
                            else if(input5 == 2){
                                System.out.println("Thank you!");
                                
                                break;
                            }
                            else{
                                System.out.println("Invalid Input!");
                                System.out.println("Exiting!");
                                
                                break;
                            }
                            break;
                            
                            
                            
                            
                            //withdraw
                        case 2:
                            System.out.print("Enter amount to withdraw    : ");
                            double withdrawAmount = scanner.nextDouble();
                            if (withdrawAmount <= balance) {
                                balance -= withdrawAmount;
                                updateBalance(accountNumber, balance);
                                System.out.println("Balance updated successfully.");
                            } else {
                                System.out.println("Insufficient balance.");
                            }
                            System.out.println("Would you like another transaction?");
                            System.out.println("1. Yes");
                            System.out.println("2. No");
                            System.out.print(": ");
                            int input4 = scanner.nextInt();
                            
                            if(input4 == 1){
                                loop = false;
                            }
                            else if(input4 == 2){
                                System.out.println("Thank you!");
                                break;
                            }
                            else{
                                System.out.println("Invalid Input!");
                                System.out.println("Exiting!");
                                break;
                            }
                            break;
                            
                            
                            //checkbalance
                        case 3:
                            System.out.println("Last Updated                : " + date);
                            System.out.println("Your current balance is     : " + balance);
                            System.out.println("Would you like another transaction?");
                            System.out.println("1. Yes");
                            System.out.println("2. No");
                            System.out.print(": ");
                            int input3 = scanner.nextInt();
                            
                            if(input3 == 1){
                                loop = false;
                            }
                            else if(input3 == 2){
                                System.out.println("Thank you!");
                                break;
                            }
                            else{
                                System.out.println("Invalid Input!");
                                System.out.println("Exiting!");
                                break;
                            }
                            break;
                        case 4:
                            System.out.println("Thank you!!!");
                            System.exit(0);
                            break;
                        default:
                            System.out.println("Invalid choice.");
                            System.exit(0);
                    }

//                    // Update balance in the file
//                    updateBalance(accountNumber, balance);
                } else {
                    System.out.println("Invalid account number or PIN.");
                    System.exit(0);
                }
            } catch (IOException e) {
                System.out.println("An error occurred while reading the account details: " + e.getMessage());
            }
        } else {
            System.out.println("Account not found.");
            System.exit(0);
        }
    }
    }

    // Method to update the balance in the file
    private void updateBalance(String accountNumber, double balance) {     
        LocalDateTime currentDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        File file = new File(accountNumber + ".txt");
        try {
            try (FileWriter writer = new FileWriter(file, true)) {
                writer.write("Balance: " + balance + "\n" + "Date: " + formattedDateTime + "\n");
            }
            
        } catch (IOException e) {
            System.out.println("An error occurred while updating the balance: " + e.getMessage());
        }
    }
}
