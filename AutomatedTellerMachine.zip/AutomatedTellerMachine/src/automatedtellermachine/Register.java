package automatedtellermachine;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class Register extends AutomatedTellerMachine {
    public void registerAccount(String fullName, int age, int pin) {
        String accnum = accountNumberGenerator.generateAccountNumber;
        String accountNumber = accnum;
        String fileName = accountNumber + ".txt";
        File file = new File(fileName);

            try (FileWriter writer = new FileWriter(file)) {
                writer.write("Full name: " + fullName + "\n");
                writer.write("Age: " + age + "\n");
                writer.write("Account number: " + accountNumber + "\n");
                writer.write("PIN: " + pin + "\n");
                writer.write("Balance: 0\n"); // Initialize balance as 0
            
            System.out.println("Account created successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while creating the account: " + e.getMessage());
        }
    }
}
