package automatedtellermachine;
import java.util.Random;
public class accountNumberGenerator {
    Random ran = new Random();
    // Method to generate a unique account number (for demonstration, it generates a random number)
    static String generateAccountNumber = "";
    void an(){
        System.out.print("Generating Account Number");
                try{
                Thread.sleep(500);
            }catch(InterruptedException e){}
                System.out.print(".");
                try{
                Thread.sleep(500);
            }catch(InterruptedException e){}
                System.out.print(".");
                try{
                Thread.sleep(500);
            }catch(InterruptedException e){}
                System.out.println(".");
                 try{
                Thread.sleep(2000);
            }catch(InterruptedException e){}
    String[] accnum = {"1","2","3","4","5","6","7","8","9","0"};
                String generatedNum = accnum[ran.nextInt(accnum.length)];
                String generatedNum2 = accnum[ran.nextInt(accnum.length)];
                String generatedNum3 = accnum[ran.nextInt(accnum.length)];
                String generatedNum4 = accnum[ran.nextInt(accnum.length)];
                String generatedNum5 = accnum[ran.nextInt(accnum.length)];
                String generatedNum6 = accnum[ran.nextInt(accnum.length)];
               //accountnumber
                String genNum = (generatedNum)+ (generatedNum2) + (generatedNum3) + "-" + (generatedNum4) + (generatedNum5) +(generatedNum6);
                accountNumberGenerator.generateAccountNumber = genNum;
    }
    
}
